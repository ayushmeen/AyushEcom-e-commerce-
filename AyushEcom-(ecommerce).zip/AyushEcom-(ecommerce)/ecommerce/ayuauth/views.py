from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.views.generic import View
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
# reset password generater
from django.contrib.auth.tokens import PasswordResetTokenGenerator
# activate the account
from django.contrib.sites.shortcuts import get_current_site
from django.utils.http import urlsafe_base64_decode,urlsafe_base64_encode
from django.urls import NoReverseMatch,reverse
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_str, DjangoUnicodeDecodeError
from django.core.mail import EmailMessage
# getting tokens from utlis 
from .utils import TokenGenrator,genrate_token
# emails
from django.core.mail import send_mail,EmailMultiAlternatives
from django.core.mail import BadHeaderError,send_mail
from django.core import mail
from django.conf import settings
from django.core.mail.message import EmailMessage
import threading
from ecommerceapp.views import index


class EmailThread(threading.Thread):
    def __init__(self,email_message):
        self.email_message=email_message
        threading.Thread.__init__(self)
    def run(self):
        self.email_message.send()

def signup(req):
    if req.method=="POST":
        email=req.POST['email']
        username=email
        password=req.POST['pass1']
        confirm_password=req.POST['pass2']
        if password!=confirm_password:
            messages.warning(req,"Password is Not Matching")
            return render(req,'signup.html')   
        try:
            if User.objects.get(username=email):
                messages.warning(req,"Email is Taken")
                return render(req,'signup.html')
        except Exception as identifier:
            pass
        user = User.objects.create_user(email,email,password)
        user.is_active=False
        user.save()
        current_site=get_current_site(req)
        email_subject="Activate Your Account"
        message=render_to_string('activate.html',{'user':user,'domain':'127.0.0.1:8000','uid':urlsafe_base64_encode(force_bytes(user.pk)),'token': genrate_token.make_token(user)})
        email_message = EmailMessage(email_subject,message,settings.EMAIL_HOST_USER,[email],)
        EmailThread(email_message).start()
        messages.info(req,"Activate Your Account By clicking link on your email")
        return redirect('/auth/login')
    return render(req,'signup.html')

class ActivateAccountView(View):
    def get(self,req,uidb64,token):
        try:
            uid=force_str(urlsafe_base64_decode(uidb64))
            user=User.objects.get(pk=uid)
        except Exception as identifier:
            user=None
        if user is not None and genrate_token.check_token(user,token):
            user.is_active=True
            user.save()
            messages.info(req,"Account Activated Successfully") 
            return redirect('/auth/login')
        return render(req,'activatefail.html')

def handlelogin(req):
    if req.method=="POST":
        username=req.POST['email']
        userpassword=req.POST['pass1']
        user=authenticate(username=username,password=userpassword)
        if user is not None:
            login(req,user)
            messages.success(req,"Login Success")
            user_name = req.user.get_full_name() or req.user.username
            url = reverse('index') + f'?user_name={user_name}'
            return redirect(url)

        else:
            messages.error(req,"Invalid Credentials")
            return redirect('/auth/login')

    return render(req,'login.html')

def handlelogout(req):
    logout(req)
    messages.success(req,"Logout Success")
    return redirect('/auth/login')

class RequestResetEmailView(View):
    def get(self,req):
        return render(req,'request-reset-email.html')

    def post(self,req):
        email=req.POST['email']
        user=User.objects.filter(email=email)
        if user.exists():
            current_site=get_current_site(req)
            email_subject="Reset Your Password"
            message=render_to_string('reset-user-password.html',{'domain':'127.0.0.1:8000','uid':urlsafe_base64_encode(force_bytes(user[0].pk)),'token': PasswordResetTokenGenerator().make_token(user[0])})
            email_message=EmailMessage(email_subject,message,settings.EMAIL_HOST_USER,[email])
            EmailThread(email_message).start()
            messages.info(req,"We have sent you an email to reset a password")
            return render(req,'request-reset-email.html')
        

class SetNewPasswordView(View):
    def get(self, req, uidb64, token):
        context = {
            'uidb64': uidb64,
            'token': token,
        }
        try:
            user_id = force_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=user_id)
            if not PasswordResetTokenGenerator().check_token(user, token):
                messages.warning(req, "Password Reset Link Is invalid")
                return render(req, 'request-reset-email.html')
        except DjangoUnicodeDecodeError:
            pass
        return render(req, 'set-new-password.html', context)
    
    def post(self, req, uidb64, token):
        context = {
            'uidb64': uidb64,
            'token': token,
        }
        password = req.POST['pass1']
        confirm_password = req.POST['pass2']
        if password != confirm_password:
            messages.warning(req, "Password is Not Matching")
            return render(req, 'set-new-password.html', context)
        try:
            user_id = force_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=user_id)
            user.set_password(password)
            user.save()
            messages.success(req, "Password Reset Success. Please Login With New Password")
            return redirect("/auth/login/")
        except DjangoUnicodeDecodeError:
            messages.error(req, "Something went wrong")
            return render(req, "auth/setpassword.html", context)
        return render(req, "set-new-password.html", context)